package com.example.webapi;

public class ListItem {
    private String product_name;
    private String size;

    public String getProduct_name() {
        return product_name;
    }

    public String getSize() {
        return size;
    }

    public ListItem(String product_name, String size) {
        this.product_name = product_name;
        this.size = size;

    }
}
